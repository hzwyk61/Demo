module.exports = function(app){
	//登陆页面
	app.get('/login',function(req,res){
		res.render('login');
	});


    //后台管理页面
	app.get('/manager/home',function(req,res){
		res.render('background/manageHome');
	});

	app.get('/manager/list',function(req,res){
		res.render('background/manageList');
	})

	app.get('/manager/add',function(req,res){
		res.render('background/addnews');
	})

    app.get('/manager/content',function(req,res){
		res.render('background/manageContent');
	})

	app.get('/manager/modify',function(req,res){
		res.render('background/manageModify');
	})

	//移动端页面
	app.get('/app/baidu',function(req,res){
		res.render('front/frontNews');
	})

	app.get('/app/baidu/newsContent',function(req,res){
		res.render('front/content');
	})
};

