$(document).ready(function(){
	$('#submit').on('click',function(e){
		e.preventDefault();
		$.ajax({
             url:'/dataInsert',
             data:$('#form').serialize(),
             type:'post',
             success: function(data){
             	if(data == 'success'){
             		alert('新闻上传成功');
             		window.location = "/manager/list";
             	}
             	if(data == 'failed'){
             		alert('新闻上传失败');
             	}
             }
		})
	})

})