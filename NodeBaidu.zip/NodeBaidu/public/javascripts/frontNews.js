$(document).ready(function() {
    // 此方法本来是想一次性添加所有数据，
    //然后用点击事件根据类别的不同实现新闻类别切换，因此在.new的div中加了vlaue="类别".
    //但是由于是异步加载，或许未添加元素的方法我只是对事件委托，可是事件委托要绑定触发事件，本宝宝就不会了
    // $.get('/newsAll', function(data) {
    //     $.each(data, function(index, element) {
    //         var news = $('<div class="new"></div>').attr('value', element.sort).appendTo($('#content'));
    //         var titleBox = $('<div class="title"></div>').appendTo(news);
    //         var title = $('<a>').attr('href', '/app/baidu/newsContent?id=' + element.id).text(element.title).appendTo(titleBox);
    //         var author = $('<div class="author"></div>').text(element.author).appendTo(news);
    //         var content = $('<div class="content"></div>').text(element.content).appendTo(news);
    //     })
    // })


    //  具体问题就在这里，如何获取到动态添加的元素而不用事件委托，或者委托事件绑定的函数可以自触发
    //  或者有更好的办法
    //  $('#recommend').on('click', function() {
    //     $('#content').on('','.new', function() {
    //             if ($(this).attr('value') != "推荐") {
    //                 $(this).addClass('hidden');
    //             }
    //     })
    // })
    

    $('.navbar').on('click',function(){
        var slug = $(this).attr('id');
        console.log(slug);

        $('.new').remove();

        $.get('/news/'+ slug, function (data){
             $.each(data, function(index, element) {
                var news = $('<div class="new"></div>').appendTo($('#content'));
                var titleBox = $('<div class="title"></div>').appendTo(news);
                var title = $('<a>').attr('href', '/app/baidu/newsContent?id=' + element.id).text(element.title).appendTo(titleBox);
                var author = $('<div class="author"></div>').text(element.author).appendTo(news);
                var content = $('<div class="content"></div>').text(element.content).appendTo(news);
            })
        })
    })

    //推荐页面作为默认页面，添加自触发事件
    $('#recommend').trigger('click');







    // $('#recommend').click(function() {
    // //确保只显示本类别，如果该类别已经加载，将不再执行click事件
    // if ($('.content *').is('.recommend')) {
    //            return
    //        }
    //     $('.technology').remove();
    //  $('.location').remove();
    //  $('.military').remove();
    //     $.get('/news/recommend', function(data) {
            // $.each(data, function(index, element) {
            //     var news = $('<div class="new recommend"></div>').appendTo($('#content'));
            //     var titleBox = $('<div class="title"></div>').appendTo(news);
            //     var title = $('<a>').attr('href', '/app/baidu/newsContent?id=' + element.id).text(element.title).appendTo(titleBox);
            //     var author = $('<div class="author"></div>').text(element.author).appendTo(news);
            //     var content = $('<div class="content"></div>').text(element.content).appendTo(news);
            // })
    //     })
    // })
    // //推荐页面作为默认页面，添加自触发事件
    // $('#recommend').trigger('click');


    // $('#technology').click(function() {
    //  if ($('.content *').is('.technology')) {
    //             return
    //         }
    //     $('.recommend').remove();
    //     $('.location').remove();
    //     $('.military').remove();
    //     $.get('/news/technology', function(data) {
    //         $.each(data, function(index, element) {
    //             var news = $('<div class="new technology"></div>').appendTo($('#content'));
    //             var titleBox = $('<div class="title"></div>').appendTo(news);
    //             var title = $('<a>').attr('href', '/app/baidu/newsContent?id=' + element.id).text(element.title).appendTo(titleBox);
    //             var author = $('<div class="author"></div>').text(element.author).appendTo(news);
    //             var content = $('<div class="content"></div>').text(element.content).appendTo(news);
    //         })
    //     })
    // })

    // $('#location').click(function() {
    //  if ($('.content *').is('.location')) {
    //             return
    //         }
    //     $('.recommend').remove();
    //     $('.technology').remove();
    //     $('.military').remove();
    //     $.get('/news/location', function(data) {
    //         $.each(data, function(index, element) {
    //             var news = $('<div class="new location"></div>').appendTo($('#content'));
    //             var titleBox = $('<div class="title"></div>').appendTo(news);
    //             var title = $('<a>').attr('href', '/app/baidu/newsContent?id=' + element.id).text(element.title).appendTo(titleBox);
    //             var author = $('<div class="author"></div>').text(element.author).appendTo(news);
    //             var content = $('<div class="content"></div>').text(element.content).appendTo(news);
    //         })
    //     })
    // })

    // $('#military').click(function() {
    //  if ($('.content *').is('.military')) {
    //             return
    //         }
    //     $('.recommend').remove();
    //     $('.location').remove();
    //     $('.technology').remove();
    //     $.get('/news/military', function(data) {
    //         $.each(data, function(index, element) {
    //             var news = $('<div class="new military"></div>').appendTo($('#content'));
    //             var titleBox = $('<div class="title"></div>').appendTo(news);
    //             var title = $('<a>').attr('href', '/app/baidu/newsContent?id=' + element.id).text(element.title).appendTo(titleBox);
    //             var author = $('<div class="author"></div>').text(element.author).appendTo(news);
    //             var content = $('<div class="content"></div>').text(element.content).appendTo(news);
    //         })
    //     })
    // })

})
