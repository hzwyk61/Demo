$(document).ready(function() {
	//获取地址栏参数
    $.getUrlParam = function(name) {
        var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
        var r = window.location.search.substr(1).match(reg);
        if (r != null) return unescape(r[2]);
        return null;
    }
    var id = $.getUrlParam('id')

    $.get('/news/newsContent', {
        id: id
    }, function(data) {
        //   console.log($(data).attr('title'));  //这里需要将data用$转化一下
       var sort = $('<b class="sort"></b>').text($(data).attr('sort')).appendTo($('.header'));
       var title = $('<p class="title"></p>').text($(data).attr('title')).appendTo($('.article'));
       var author = $('<span class="author"></span>').text($(data).attr('author')).appendTo($('.article'));
       var date = $('<span class="date"></span>').text($(data).attr('dateline')).appendTo($('.article'));
       var content = $('<p class="content"></p>').text($(data).attr('content')).appendTo($('.article'));
    })

    $("#back").click(function() {
        window.history.go(-1);
    })


})
