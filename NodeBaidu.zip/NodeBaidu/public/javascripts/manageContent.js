$(document).ready(function() {
    $.getUrlParam = function(name) {
        var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
        var r = window.location.search.substr(1).match(reg);
        if (r != null) return unescape(r[2]);
        return null;
    }
    var id = $.getUrlParam('id')

    $.get('/database/findOne', {
        id: id
    }, function(data) {
        //   console.log($(data).attr('title'));  //这里需要将data用$转化一下
        var title = $('<div class="newTitle"></div>').text($(data).attr('title')).appendTo($('.article'));
        var author = $('<div class="newAuthor"></div>').text($(data).attr('author')).appendTo($('.article'));
        var content = $('<div class="newCon"></div>').text($(data).attr('content')).appendTo($('.article'));
    })
})
