$(document).ready(function(){
	$.get('/database',function(data){
		$.each(data,function(index,element){
			box = $('<div>').addClass("panel panel-default").appendTo($('.homePage'));
			boxHead = $('<div>').addClass("panel-heading artTitle").appendTo(box);
			//title = $('<h2></h2>').text(element.title).appendTo($('.artTitle'));
			author = $('<small>').text('作者:'+$(element).attr('author')).appendTo(boxHead);
			boxH = $('<h2>').appendTo(boxHead);
			title = $('<a>').attr({
				'value':element.id,
			    'href':'/manager/content?id='+element.id})
			.text($(element).attr('title')).appendTo(boxH);
			content = $('<div>').addClass("panel-body abstract").text(element.content).appendTo(box);
		});
	});
});

