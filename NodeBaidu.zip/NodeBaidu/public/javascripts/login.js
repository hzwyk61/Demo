$(function(){
	$('#btn').click(function(e){
        e.preventDefault();
        $.post('/userLogin',{
        	userName:$('#userName').val(),
        	userPassword:$('#password').val()
        },function(data){
            if(data == "allow"){
            	window.location.href = "/manager/home";
            } else if(data == "failed"){
            	alert('登录失败，请重新输入');
            	$('.loginForm')[0].reset();
            }
        })
	})
})