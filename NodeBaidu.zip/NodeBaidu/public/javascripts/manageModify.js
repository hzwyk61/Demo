$(document).ready(function() {
    //获取地址栏中的参数
    $.getUrlParam = function(name) {
        var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
        var r = window.location.search.substr(1).match(reg);
        if (r != null) return unescape(r[2]);
        return null;
    }
    var id = $.getUrlParam('id');

    //将地址栏获取的参数传到服务器，并返回需要修改的文章。并用动态添加的方法将数据显示在页面中
    $.get('/database/findOne', {
        id: id
    }, function(data) {   //这里有个疑问，如何将data数据用<% = ...%>的方法直接添加在ejs中
        var title = $('<input type="text" name="title" class="form-control">').attr('value',$(data).attr('title')).appendTo($('.formTitle'));
        var author = $('<input type="text" name="author" class="form-control">').attr('value',$(data).attr('author')).appendTo($('.formAuthor'));
        var content = $('<textarea class="form-control" name="content" rows="9"></textarea>').text($(data).attr('content')).appendTo($('.formContent'));
        var id = $('#newsId').attr('value',$(data).attr('id'));
        
        // 新闻类别的确认
        var option = new Array();
        $('.formsort option').each(function(){
           // option = $(this).val();
            if($(this).val() == $(data).attr('sort')){
              $(this).attr('selected','selected')
            }
        })
    })

    //修改后的新闻导入
    $('#submit').on('click',function(e){
    e.preventDefault();
    $.ajax({
             url:'/updata',
             data:$('#form').serialize(),
             type:'post',
             success: function(data){
             console.log(data);
              if(data == 'success'){
                alert('新闻修改成功');
                window.location = "/manager/list";
              }
              if(data == 'failed'){
                alert('新闻修改失败');
              }
            }
    })
  })

})
