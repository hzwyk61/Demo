$(document).ready(function(){
  $.get('/database',function(data){
         $.each(data,function(index,element){
         	tbody = $('<tr>').addClass('warning').appendTo($('.table'));
         	id = $('<td>').text(element.id).appendTo(tbody);

         	titleBox = $('<td></td>').addClass('titleWidth').appendTo(tbody);
         	title = $('<a></a>').attr('href','/manager/content?id='+element.id).text(element.title).appendTo(titleBox);
            author = $('<td>').text(element.author).appendTo(tbody);
         	sort = $('<td>').text(element.sort).appendTo(tbody);
         	date = $('<td>').text(element.dateline).appendTo(tbody);

         	handleTd = $('<td>').addClass('handleTd').appendTo(tbody);
         	handleBtn = $('<div>').addClass('button-group').appendTo(handleTd);
         	revise = $('<a>').attr('href','/manager/modify?id='+element.id).addClass('button button-pill button-action button-raised button-rounded operate').text('修改').appendTo(handleBtn);
         	del = $('<a>').attr('value',element.id).addClass('button button-pill button-action button-raised button-rounded operate delLink').text('删除').appendTo(handleBtn);
         });
    });
  //   新闻删除，    给动态添加元素绑定事件的方法
  $('.table').on('click','.delLink',function(){            
        // console.log($(this).attr('value'));
        if(confirm('您确定要删除吗？')){
            $.get('/database/delNews',
                {id:$(this).attr('value')},function(data){
                    if(data == 'success'){
                        alert('新闻删除成功！');
                        window.location = "/manager/list";
                    }else{
                        alert('新闻删除失败！');
                    }
            });
        };
  });
});
