var express = require('express');
var router = express.Router();
var orm = require('orm');

//登陆验证
router.post('/userLogin', function(req, res, next) {
    orm.connect("mysql://root:@localhost/news_manager", function(err, db) {
        if (err) throw err;
        var msg = db.define("users", {
            userId: {
                type: 'serial',
                key: true
            },
            userName: String,
            userPassword: String
        });
        msg.find({
            userName: req.body.userName
        }, function(err, item) {
            if (err) throw err;
            //res.send(item[0].userPassword)
            if (item == "") {
                res.status(403);
                res.send('failed');
            } else if (req.body.userPassword != item[0].userPassword) {
                res.status(403);
                res.send('failed');
            } else {
                res.status(200);
                res.send('allow')
            }
        })
    })
})


//读取定义数据库
router.use(orm.express("mysql://root:@localhost/news_manager", {
    define: function(db, models, next) {
        models.news = db.define("baidunews", {
            id: {
                type: 'serial',
                key: true
            },
            title: String,
            author: String,
            sort: String,
            content: String,
            dateline: Date,
        });
        next();
    }
}));


// ajax显示后台首页的新闻数据
router.get('/database', function(req, res, next) {
    req.models.news.find({}, function(err, news) {
        if (err) throw err;
        res.json(news); //将数据返回给ajax
    });
});

//将ajxa传入的数据导入数据库,添加文章
router.post('/dataInsert', function(req, res, next) {
    var addDate = new Date();
    var insertTime = addDate.toLocaleDateString();
    req.models.news.create({
        title: req.body.title,
        author: req.body.author,
        sort: req.body.sort,
        content: req.body.content,
        dateline: insertTime
    }, function(err, news) {
        if (err) {
            res.status(403);
            res.send('faied');
        } else {
            res.status(200);
            res.send('success')
        }
    })
})

//查找显示某一篇新闻
router.get('/database/findOne', function(req, res, next) {
    req.models.news.find({
        id: req.query.id
    }, function(err, news) {
        if (err) throw err;
        res.json(news); //将数据返回给ajax
    });
});


//修改一篇文章
router.post('/updata', function(req, res, next) {
    var addDate = new Date();
    var updataTime = addDate.toLocaleDateString();
    req.models.news.find({
        id: req.body.id
    }, function(err, item) {
        item[0].title = req.body.title;
        item[0].author = req.body.author;
        item[0].sort = req.body.sort;
        item[0].content = req.body.content;
        item[0].dateline = updataTime;
        item[0].save(function(err) {
            if (err) {
                res.status(403);
                res.send('faied');
            } else {
                res.status(200);
                res.send('success')
            }
        })
    })

})


//删除某一篇文章
router.get('/database/delNews', function(req, res, next) {
    req.models.news.find({
        id: req.query.id //req.query多用于get方法
    }).remove(function(err, news) {
        if (err) throw err;
        if (!err) {
            res.status(200);
            res.send('success');
        }
    })
})



//移动端页面
router.get('/newsAll',function (req,res,next) {
    req.models.news.find({},function (err,news){
        if (err) throw err ;
        res.json(news);
    })
})


//默认，推荐页
router.get('/news/recommend', function(req, res, next) {
    req.models.news.find({
        sort: "推荐"
    }, function(err, news) {
        if (err) throw err;
        res.json(news);
    })
})

//科技页面
router.get('/news/technology', function(req, res, next) {
    req.models.news.find({
        sort: "科技"
    }, function(err, news) {
        if (err) throw err;
        res.json(news);
    })
})

//本地页面
router.get('/news/location', function(req, res, next) {
    req.models.news.find({
        sort: "本地"
    }, function(err, news) {
        if (err) throw err;
        res.json(news);
    })
})

//军事页面
router.get('/news/military', function(req, res, next) {
    req.models.news.find({
        sort: "军事"
    }, function(err, news) {
        if (err) throw err;
        res.json(news);
    })
})

//具体内容页
router.get('/news/newsContent', function(req, res, next) {
    req.models.news.find({
        id: req.query.id
    }, function(err, news) {
        if (err) throw err;
        res.json(news);
    })
})

module.exports = router;
